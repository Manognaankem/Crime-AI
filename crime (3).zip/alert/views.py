from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
import os
import numpy as np
import librosa
import joblib
from django.conf import settings
from django.core.files.storage import FileSystemStorage

# Home page (Protected - Requires Login)
@login_required(login_url='login')
def index(request):
    return render(request, 'index.html')

@login_required(login_url='login')
def about(request):
    return render(request, 'about.html')

@login_required(login_url='login')
def contact(request):
    return render(request, 'contact.html')

# Login View
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            auth_login(request, user)
            messages.success(request, "Login successful!")
            return redirect('index')
        else:
            messages.error(request, "Invalid username or password.")
    
    return render(request, 'login.html')

# Signup View
def signup(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']

        # Validation
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken!")
            return redirect('signup')
        
        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return redirect('signup')
        
        if len(password) < 6:
            messages.error(request, "Password must be at least 6 characters long.")
            return redirect('signup')

        # Create user
        user = User.objects.create_user(username=username, password=password)
        user.save()
        messages.success(request, "Signup successful! Please log in.")
        return redirect('login')

    return render(request, 'signup.html')

# Logout View
@login_required(login_url='login')
def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect('login')

# Load the trained scream detection model
MODEL_PATH = os.path.join(settings.BASE_DIR, 'scream_detector_model.pkl')
classifier = joblib.load(MODEL_PATH)

# Function to extract MFCC features from an audio file
def extract_features(file_path, n_mfcc=13):
    try:
        audio, sample_rate = librosa.load(file_path, sr=None)
        mfccs = librosa.feature.mfcc(y=audio, sr=sample_rate, n_mfcc=n_mfcc)
        return np.mean(mfccs, axis=1)
    except Exception as e:
        print(f"Error processing {file_path}: {e}")
        return None

# Function to predict scream or non-scream
def predict_scream(file_path):
    features = extract_features(file_path)
    if features is not None:
        features = np.array([features])  # Reshape for model input
        prediction = classifier.predict(features)
        label = "Scream Detected ⚠️" if prediction[0] == 1 else "No Scream Detected ✅"
        return label
    else:
        return "Error in audio processing."

# Django view to handle file upload and prediction
def scream_detection_view(request):
    context = {'prediction': None, 'audio_url': None}

    if request.method == 'POST' and request.FILES.get('audio_file'):
        audio_file = request.FILES['audio_file']
        fs = FileSystemStorage()
        filename = fs.save(audio_file.name, audio_file)
        audio_file_path = fs.path(filename)
        audio_url = fs.url(filename)

        # Make prediction
        prediction = predict_scream(audio_file_path)
        context['prediction'] = prediction
        context['audio_url'] = audio_url

    return render(request, 'scream_detection.html', context)